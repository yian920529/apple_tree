// main.dart
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'second_page.dart';
import 'third_page.dart';

List<AccountData> accountDataList = [];
int income = 0;
int expense = 0;
int balance = 0;
int amount =0;
double target = income/4;
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key,});

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final TextEditingController _incomeController = TextEditingController();

  @override
  void initState() {
    super.initState();
    balance = income - expense;
    target =income/4;
  }

  void _showResetIncomeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('重新輸入收入'),
          content: Text('是否重新輸入收入?如果是的話,紀錄會被清空。'),
          actions: <Widget>[
            TextButton(
              child: Text('取消'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: Text('確定'),
              onPressed: () {
                setState(() {
                  income = 0;
                  expense = 0;
                  balance = 0;
                  target =income/4;
                  _incomeController.clear();
                  accountDataList.clear();
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final appBar = AppBar(
      title: const Text('Home'),
    );

    var img3 = SizedBox(
      width: 300,
      height: 300,
      child: Image.asset(
        'assets/appleTree.png',
        fit: BoxFit.contain,
      ),
    );
    var img2 = SizedBox(
      width: 300,
      height: 300,
      child: Image.asset(
        'assets/flower.png',
        fit: BoxFit.contain,
      ),
    );
    var img1 = SizedBox(
      width: 300,
      height: 300,
      child: Image.asset(
        'assets/littleTree.png',
        fit: BoxFit.contain,
      ),
    );
    var img0 = SizedBox(
      width: 300,
      height: 300,
      child: Image.asset(
        'assets/seed.png',
        fit: BoxFit.contain,
      ),
    );
    var img;
    if (balance>target*3)
    {
      img =img3;
    }
    else if (balance>target*2)
    {
      img =img2;
    }
    else if (balance>target*1)
    {
      img =img1;
    }
    else
    {
      img =img0;
    }
    var appBody = Column(
      children: <Widget>[
        Expanded(
          child: img,
        ),
        Text('本週開銷:'),
        TextField(
          controller: _incomeController,
          decoration: const InputDecoration(
            labelText: '輸入收入',
          ),
          keyboardType: TextInputType.number,
          onChanged: (value) {
            setState(() {
              income = int.tryParse(value) ?? 0;
              balance = income - expense;
              target =income/4;
            });
          },
          onTap: () {
            if (income != 0) {
              _showResetIncomeDialog();
            }
          },
        ),
        Text('收入: $income'),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('支出: $expense'),
          ],
        ),
        Text('餘額: $balance'),
        Padding(
          padding: const EdgeInsets.all(0.0),
          child: Row(
            children: [
              Container(
                child: InkWell(
                    child: Image(
                        image: AssetImage("assets/HOME.png"), width: 139)),
              ),
              Container(
                child: InkWell(
                    onTap: () => Navigator.push(
                      context,
                      PageRouteBuilder(
                          pageBuilder: (
                              BuildContext context,
                              Animation<double> animation,
                              Animation<double> secondaryAnimation,
                              ) =>
                              SecondPage(
                                amountCallback: (amount) {
                                  setState(() {
                                    target =income/4;
                                    expense += amount;
                                    balance = income - expense;
                                  });
                                },
                              ),
                          transitionsBuilder: (
                              BuildContext context,
                              Animation<double> animation,
                              Animation<double> secondaryAnimation,
                              Widget child,
                              ) =>
                              SlideTransition(
                                position: Tween(
                                  begin: const Offset(1, 0),
                                  end: Offset.zero,
                                ).animate(animation),
                                child: child,
                              ),
                          transitionDuration:
                          const Duration(milliseconds: 300)),
                    ),
                    child: Image(
                      image: AssetImage("assets/PLUS.png"), width: 122.5,)
                ),
              ),
              Container(
                child: InkWell(
                    onTap: () => Navigator.push(
                        context,
                        PageRouteBuilder(
                          pageBuilder: (
                              BuildContext context,
                              Animation<double> animation,
                              Animation<double> secondaryAnimation,
                              ) =>
                              ThirdPage(accountDataList: accountDataList),
                          transitionsBuilder: (
                              BuildContext context,
                              Animation<double> animation,
                              Animation<double> secondaryAnimation,
                              Widget child,
                              ) =>
                              SlideTransition(
                                position: Tween(
                                  begin: const Offset(1, 0),
                                  end: Offset.zero,
                                ).animate(animation),
                                child: child,
                              ),
                          transitionDuration: const Duration(milliseconds: 300),
                        )),
                    child: Image(
                        image: AssetImage("assets/CHART.png"), width: 129)),
              ),
            ],
          ),
        ),
      ],
    );

    final appHomePage = Scaffold(
      appBar: appBar,
      body: appBody,
    );

    return appHomePage;
  }
}