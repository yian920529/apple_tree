import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'main.dart';
import 'third_page.dart';

class AccountData {
  final String name;
  final int amount;
  final String category;

  AccountData(
      {required this.name, required this.amount, required this.category});
}

typedef void AmountCallback(int amount);

class SecondPage extends StatefulWidget {
  final AmountCallback amountCallback;

  const SecondPage({Key? key, required this.amountCallback}) : super(key: key);

  @override
  State<SecondPage> createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _categoryController = TextEditingController();

  late AmountCallback _amountCallback;

  @override
  void initState() {
    super.initState();
    _amountCallback = widget.amountCallback;
  }

  @override
  Widget build(BuildContext context) {
    final appBar = AppBar(
      title: const Text('Account'),
      backgroundColor: Colors.amber,
    );

    final page = Scaffold(
      appBar: appBar,
      body: Column(
          children: <Widget>[
            Column(
              children: [
                TextField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: '名稱',
                  ),
                ),
                TextField(
                  controller: _amountController,
                  decoration: const InputDecoration(
                    labelText: '金額',
                  ),
                ),
                TextField(
                  controller: _categoryController,
                  decoration: const InputDecoration(
                    labelText: '類別',
                  ),
                ),
              ],
            ),

            ElevatedButton(
              onPressed: () {
                amount = int.parse(_amountController.text);
                final name = _nameController.text;
                final category = _categoryController.text;
                _amountCallback(amount);
                final accountData =
                    AccountData(name: name, amount: amount, category: category);
                accountDataList.add(accountData);
                Navigator.push(
                    context,
                    PageRouteBuilder(
                      pageBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                      ) =>
                          MyHomePage(),
                      transitionsBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                        Widget child,
                      ) =>
                          SlideTransition(
                        position: Tween(
                          begin: const Offset(1, 0),
                          end: Offset.zero,
                        ).animate(animation),
                        child: child,
                      ),
                      transitionDuration: const Duration(milliseconds: 300),
                    ));
              },
              child: const Text('確定'),
            ),
            Expanded(
              child: Container(

              ),
            ),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: Row(
                children: [
                  Container(
                    child: InkWell(
                        onTap: () => Navigator.push(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (
                                BuildContext context,
                                Animation<double> animation,
                                Animation<double> secondaryAnimation,
                              ) =>
                                  MyHomePage(),
                              transitionsBuilder: (
                                BuildContext context,
                                Animation<double> animation,
                                Animation<double> secondaryAnimation,
                                Widget child,
                              ) =>
                                  SlideTransition(
                                position: Tween(
                                  begin: const Offset(1, 0),
                                  end: Offset.zero,
                                ).animate(animation),
                                child: child,
                              ),
                              transitionDuration:
                                  const Duration(milliseconds: 300),
                            )),
                        child: Image(
                            image: AssetImage("assets/HOME.png"), width: 139)),
                  ),
                  Container(
                    child: InkWell(
                        child: Image(
                      image: AssetImage("assets/PLUS.png"),
                      width: 122.5,
                    )),
                  ),
                  Container(
                    child: InkWell(
                        onTap: () => Navigator.push(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (
                                BuildContext context,
                                Animation<double> animation,
                                Animation<double> secondaryAnimation,
                              ) =>
                                  ThirdPage(accountDataList: accountDataList),
                              transitionsBuilder: (
                                BuildContext context,
                                Animation<double> animation,
                                Animation<double> secondaryAnimation,
                                Widget child,
                              ) =>
                                  SlideTransition(
                                position: Tween(
                                  begin: const Offset(1, 0),
                                  end: Offset.zero,
                                ).animate(animation),
                                child: child,
                              ),
                              transitionDuration:
                                  const Duration(milliseconds: 300),
                            )),
                        child: Image(
                            image: AssetImage("assets/CHART.png"), width: 129)),
                  ),
                ],
              ),
            )
          ],
        ),
      backgroundColor: const Color.fromARGB(255, 220, 220, 220),
    );

    return page;
  }
}
