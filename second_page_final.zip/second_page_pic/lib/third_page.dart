import 'package:flutter/material.dart';
import 'main.dart';
import 'second_page.dart';

class ThirdPage extends StatefulWidget {
  final List<AccountData> accountDataList;

  const ThirdPage({Key? key, required this.accountDataList}) : super(key: key);

  @override
  State<ThirdPage> createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  @override
  Widget build(BuildContext context) {
    final appBar = AppBar(
      title: const Text('List'),
      backgroundColor: Colors.amber,
    );

    final listViewWidget = ListView.builder(
      itemCount: widget.accountDataList.length,
      itemBuilder: (context, index) {
        final accountData = widget.accountDataList[index];
        return Dismissible(
          key: Key(accountData.name),
          onDismissed: (direction) {
            setState(() {
              expense -= accountData.amount;
              balance = income - expense;
              widget.accountDataList.removeAt(index);
            });
          },
          child: ListTile(
            title: Text(
              '名稱: ${accountData.name}, 金額: ${accountData.amount}, 類別: ${accountData.category}',
              style: const TextStyle(fontSize: 20),
            ),
          ),
        );
      },
    );

    final btn0 = Container(
      child: InkWell(
          onTap: () =>
              Navigator.push(context,
                  PageRouteBuilder(
                    pageBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                        ) => const MyHomePage(),
                    transitionsBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                        Widget child,
                        ) => SlideTransition(
                      position: Tween(
                        begin: const Offset(1, 0),
                        end: Offset.zero,
                      ).animate(animation),
                      child: child,
                    ),
                    transitionDuration: const Duration(milliseconds: 300),)
              ),
          child: Image(image:AssetImage("assets/HOME.png"),width: 139,)
      ),
    );
    // 建立App的操作畫面
    final btn1 = Container(
      child: InkWell(
          onTap: () =>
              Navigator.push(context,
                  PageRouteBuilder(
                    pageBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                        ) => SecondPage(
                        amountCallback: (amount) {setState(() {
                          expense += amount;
                          balance = income - expense;
                        });}
                    ),
                    transitionsBuilder: (
                        BuildContext context,
                        Animation<double> animation,
                        Animation<double> secondaryAnimation,
                        Widget child,
                        ) => SlideTransition(
                      position: Tween(
                        begin: const Offset(1, 0),
                        end: Offset.zero,
                      ).animate(animation),
                      child: child,
                    ),
                    transitionDuration: const Duration(milliseconds: 300),)
              ),
          child: Image(image:AssetImage("assets/PLUS.png"),width:122.5,)
      ),
    );
    final btn2 = Container(
      child: InkWell(
          child: Image(image:AssetImage("assets/CHART.png"),width: 129,)
      ),
    );
    final bottomWidget = Column(
      children: [
        Expanded(child: listViewWidget),
        Container(
          alignment: Alignment.bottomCenter,

          child: Row(
            children: [btn0,btn1,btn2],
          ),
        ),
      ],
    );

    final page = Scaffold(
      appBar: appBar,
      body: bottomWidget,
      backgroundColor: const Color.fromARGB(255, 100, 100, 255),
    );

    return page;
  }
}